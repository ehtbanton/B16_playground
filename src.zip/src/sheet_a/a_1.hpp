#include <iostream>

inline void q1_say_hello()
{
	std::cout << "Hello World!\n";
}